chrome.devtools.panels.create("Test Generator",
                                    "icon.png",
                                    "index.html",
                                    function(panel){  
                                   } );
